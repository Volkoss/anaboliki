$(document).ready(function() {

	console.log(' in common.js! ');

})